create view pvview as
select sum(`vueblog2`.`pv`.`pv`) AS `pv`, `vueblog2`.`pv`.`uid` AS `uid`
from `vueblog2`.`pv`
group by `vueblog2`.`pv`.`uid`;

